package com.example.todoapp.Model

class ToDoModel {
    var task: String? = null
    var id = 0
    var status = 0
}