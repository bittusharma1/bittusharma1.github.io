package com.example.todoapp.Utils

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.todoapp.Model.ToDoModel
import java.util.ArrayList
import java.util.List

class DataBaseHelper(@Nullable context: Context?) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, 1) {
    private var db: SQLiteDatabase? = null
    @Override
    fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE_NAME + "(ID INTEGER PRIMARY KEY AUTOINCREMENT , TASK TEXT , STATUS INTEGER)")
    }

    @Override
    fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME)
        onCreate(db)
    }

    fun insertTask(model: ToDoModel) {
        db = this.getWritableDatabase()
        val values = ContentValues()
        values.put(COL_2, model.getTask())
        values.put(COL_3, 0)
        db.insert(TABLE_NAME, null, values)
    }

    fun updateTask(id: Int, task: String?) {
        db = this.getWritableDatabase()
        val values = ContentValues()
        values.put(COL_2, task)
        db.update(TABLE_NAME, values, "ID=?", arrayOf<String>(String.valueOf(id)))
    }

    fun updateStatus(id: Int, status: Int) {
        db = this.getWritableDatabase()
        val values = ContentValues()
        values.put(COL_3, status)
        db.update(TABLE_NAME, values, "ID=?", arrayOf<String>(String.valueOf(id)))
    }

    fun deleteTask(id: Int) {
        db = this.getWritableDatabase()
        db.delete(TABLE_NAME, "ID=?", arrayOf<String>(String.valueOf(id)))
    }

    val allTasks: List<Any>
        get() {
            db = this.getWritableDatabase()
            var cursor: Cursor? = null
            val modelList: List<ToDoModel> = ArrayList()
            db.beginTransaction()
            try {
                cursor = db.query(TABLE_NAME, null, null, null, null, null, null)
                if (cursor != null) {
                    if (cursor.moveToFirst()) {
                        do {
                            val task = ToDoModel()
                            task.setId(cursor.getInt(cursor.getColumnIndex(COL_1)))
                            task.setTask(cursor.getString(cursor.getColumnIndex(COL_2)))
                            task.setStatus(cursor.getInt(cursor.getColumnIndex(COL_3)))
                            modelList.add(task)
                        } while (cursor.moveToNext())
                    }
                }
            } finally {
                db.endTransaction()
                cursor.close()
            }
            return modelList
        }

    companion object {
        private const val DATABASE_NAME = "TODO_DATABASE"
        private const val TABLE_NAME = "TODO_TABLE"
        private const val COL_1 = "ID"
        private const val COL_2 = "TASK"
        private const val COL_3 = "STATUS"
    }
}