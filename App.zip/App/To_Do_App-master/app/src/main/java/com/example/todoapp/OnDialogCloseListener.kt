package com.example.todoapp

import android.content.DialogInterface

interface OnDialogCloseListener {
    fun onDialogClose(dialogInterface: DialogInterface?)
}