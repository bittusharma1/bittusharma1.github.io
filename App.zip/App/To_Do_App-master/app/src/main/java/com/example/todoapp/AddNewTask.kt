package com.example.todoapp

import android.app.Activity
import android.content.DialogInterface
import android.graphics.Color
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import com.example.todoapp.Model.ToDoModel
import com.example.todoapp.Utils.DataBaseHelper
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class AddNewTask : BottomSheetDialogFragment() {
    private var mEditText: EditText? = null
    private var mSaveButton: Button? = null
    private var myDb: DataBaseHelper? = null

    @Nullable
    @Override
    fun onCreateView(
        @NonNull inflater: LayoutInflater,
        @Nullable container: ViewGroup?,
        @Nullable savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.add_new_task, container, false)
    }

    @Override
    fun onViewCreated(@NonNull view: View, @Nullable savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        mEditText = view.findViewById(R.id.edittext)
        mSaveButton = view.findViewById(R.id.button_save)
        myDb = DataBaseHelper(getActivity())
        var isUpdate = false
        val bundle: Bundle = getArguments()
        if (bundle != null) {
            isUpdate = true
            val task: String = bundle.getString("task")
            mEditText.setText(task)
            if (task.length() > 0) {
                mSaveButton.setEnabled(false)
            }
        }
        mEditText.addTextChangedListener(object : TextWatcher() {
            @Override
            fun beforeTextChanged(s: CharSequence?, i: Int, i1: Int, i2: Int) {
            }

            @Override
            fun onTextChanged(s: CharSequence, i: Int, i1: Int, i2: Int) {
                if (s.toString().equals("")) {
                    mSaveButton.setEnabled(false)
                    mSaveButton.setBackgroundColor(Color.GRAY)
                } else {
                    mSaveButton.setEnabled(true)
                    mSaveButton.setBackgroundColor(getResources().getColor(R.color.colorPrimary))
                }
            }

            @Override
            fun afterTextChanged(editable: Editable?) {
            }
        })
        val finalIsUpdate = isUpdate
        mSaveButton.setOnClickListener(object : OnClickListener() {
            @Override
            fun onClick(view: View?) {
                val text: String = mEditText.getText().toString()
                if (finalIsUpdate) {
                    myDb.updateTask(bundle.getInt("id"), text)
                } else {
                    val item = ToDoModel()
                    item.setTask(text)
                    item.setStatus(0)
                    myDb.insertTask(item)
                }
                dismiss()
            }
        })
    }

    @Override
    fun onDismiss(@NonNull dialog: DialogInterface?) {
        super.onDismiss(dialog)
        val activity: Activity = getActivity()
        if (activity is OnDialogCloseListener) {
            (activity as OnDialogCloseListener).onDialogClose(dialog)
        }
    }

    companion object {
        const val TAG = "AddNewTask"
        fun newInstance(): AddNewTask {
            return AddNewTask()
        }
    }
}